import { v4 as uuid } from "uuid";
import { useState } from "react";
import "./styles.css";

const todoList = [
  // {
  //   id: uuid(),
  //   title: "React Practice Set 8",
  //   completed: false
  // },
  // {
  //   id: uuid(),
  //   title: "Make video on top languages to learn in 2023",
  //   completed: false
  // },
];
const ToDoList = ({ list, toggleButtonHandler }) => {
  const toggleButton = (id) => {
    toggleButtonHandler(id);
  };
  return (
    <div>
      {list.map((item) => (
        <li
          key={item.id}
          onClick={() => toggleButton(item.id)}
          style={{
            color: item.completed && "red",
            textDecoration: item.completed && "line-through"
          }}
        >
          {item.title}
        </li>
      ))}
    </div>
  );
};

export default function App() {
  const [list, setList] = useState(todoList);
  const [inputValue, setInputValue] = useState("");
  const buttonHandler = (id) => {
    const updatedList = list.map((item) =>
      item.id === id ? { ...item, completed: !item.completed } : { ...item }
    );
    setList(updatedList);
  };
  const { done, pending } = list.reduce(
    (acc, curr) =>
      curr.completed
        ? { ...acc, done: (acc.done ?? 0) + 1 }
        : { ...acc, pending: (acc.pending ?? 0) + 1 },
    { done: 0, pending: 0 }
  );
  const addToList = () => {
    if (inputValue.trim() !== "") {
      setList((prevList) => [
        ...prevList,
        { id: uuid(), title: inputValue, completed: false }
      ]);
      setInputValue("");
    }
  };
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      addToList();
    }
  };
  return (
    <div>
      <div className="Header">
        <h1>
          Done : <span>{done} </span>|| Pending: <span>{pending}</span>
        </h1>
      </div>
      <div>
        <input
          type="text"
          placeholder="Enter your Tasks"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        <button onClick={addToList}>Add Task</button>
      </div>

      <ToDoList list={list} toggleButtonHandler={buttonHandler} />
      {done >= list.length && done !== 0 && (
        <h1 style={{ fontSize: "16px" }}>
          Congratulations
          <span role="img" aria-label="rocket">
            🚀
          </span>
          , You have accomplished all of today's tasks with success.
        </h1>
      )}
    </div>
  );
}
